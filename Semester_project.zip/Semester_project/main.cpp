#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    srand(time(0));

    string questions[16] = {
        "What is 2+2?", "What is 3+3?", "What is 4+4?", "What is 5+5?", "What is 6+6?",
        "What is the chemical symbol for water?", "What is the largest planet in our solar system?",
        "What is the plural form of 'child'?", "Which word is a synonym for 'happy'?",
        "What does URL stand for?", "What is the programming language C++ mainly used for?"
    };
    
    string answers[16] = {
        "4", "6", "8", "10", "12",
        "H2O", "Jupiter",
        "children", "joyful",
        "Uniform Resource Locator", "Software development"
    };

    int score = 0;

    cout << "Welcome to the Quiz!" << endl;
    cout << "Answer the following questions:" << endl;

    int questionOrder[16] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
    for (int i = 0; i < 16; i++) {
        int randIndex = rand() % 16;
        swap(questionOrder[i], questionOrder[randIndex]);
    }

    for (int i = 0; i < 16; i++) {
        int index = questionOrder[i];
        cout << questions[index] << " ";
        string userAnswer;
        cin >> userAnswer;

        if (userAnswer == answers[index]) {
            cout << "CORRECT! ";
            score++;
        } else {
            cout << "Incorrect. The answer is " << answers[index] << ". ";
        }
    }

    cout << "Your score is " << score << " out of 16." << endl;

    return 0;
}

